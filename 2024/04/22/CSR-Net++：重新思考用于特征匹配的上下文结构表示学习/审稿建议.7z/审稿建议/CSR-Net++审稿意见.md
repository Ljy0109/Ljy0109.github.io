Summary Of The Paper:

这篇论文以 CSR-Net 为基础，提出了改进的方法 CSR-Net++ 用于错误匹配去除任务。给定一组假定匹配集合，使用PointNet架构计算匹配之间的全局相似度，然后使用了一种Two-Stream Architecture计算匹配之间的局部相似度。与CSR-Net相比，CSR-Net++从使用PointNet架构估计全局变换模型改为了使用PointNet架构计算匹配之间的全局相似度，并基于全局相似度修改了CSR-Net中的距离度量函数。此外，CSR-Net++引入了原始图像信息，将其与匹配的空间信息结合，共同表示匹配的局部相似性。



major concern：

1. 对于图2中的$k\times D$张量，CSR-Net是沿着$k$所在的维度进行Max Pooling操作，从而保证STR具有permutation-invariance。但是CSR-Net++是沿着$D$所在的维度进行分段点积和线性投影的操作。那么在CSR-Net++中，是什么操作保证STR具有permutation-invariance？以及为什么这个操作可以保证permutation-invariance？建议在文章中进行强调。
2. 关于数据集SUIR和MTI的实验数据在哪里？4.4节中的数据集RS-satellite和RS-UAV与4.2节中介绍的数据集有什么关系？图4和图6中的图像分别来自哪些数据集？对于OxBs 数据集，作者是如何获得它的Ground Truth，是否可以提供相关文件？MTI数据集似乎无法获得，作者是否可以提供相关链接或者获取途径？
3. 对于4.5节Image Registration，论文应该说明是通过什么方法计算变换模型TPS和单应性矩阵的。不同的计算方法可能会导致不同的实验结果。此外，图6似乎只显示了以单应性矩阵作为变换模型的图像配准结果？
4. 论文应该讨论图2的超参数Patch-size、$C$和$D$对算法性能的影响
5. 论文应该在结论处对提出方法的不足和未来改进的方向进行分析。
6. 方法在数据集上的实验数据不能称作贡献。建议重新组织引言第五段的语言。



minor concern：

1. 变量第一次出现时，应该对其进行必要的说明。比如公式5中的n和公式6中的$C$、$D$。

2. 图1表达的算法细节不够清楚，特别是图1第一行（见下图）。蓝色框选中的部分容易使读者产生误解，从而使读者认为模型中的张量的维度无法对齐。建议参照PointNet Segmentation Network的流程图进行修改，或者将必要的张量及其维度标注在图1上。下图中两个红色框选中区域以及两者之间的关系缺乏必要的解释，建议结合公式4进行说明。

   ![](E:\Code\blog\source\_posts\CSR-Net++：重新思考用于特征匹配的上下文结构表示学习\审稿1.jpg)

3. 图1中的PointNet Encoder和CNN Encoder缺少必要的参数说明。Rotation Invariant Layer缺少对具体操作的说明。
4. 公式6中的$\mathcal{P}_i^i$ 包含两个$i$。这两个$i$的含义似乎不一样，建议修改此处的变量名。建议在论文中说明$\mathcal{P}_i$与$\mathcal{P}_i^i$的关系。
5. 建议在论文中说明图2的Spatial STR与正文的$\mathcal{R}_i$、$\mathcal{R}_{ij}$的关系。
6. 公式7中的$\mathcal{L}_{local}$应该写出其表达式。



Summary Of The Review:

总的来说，这篇论文提出的方法具有一个不错的想法。但是论文对方法的描述不够清楚，需要进一步组织语言。







**Summary Of The Paper:**

This paper builds upon CSR-Net and proposes an enhanced method, CSR-Net++, for the task of mismatch removal. Given a set of putative matches, the global similarity between matches is computed using the PointNet architecture, followed by the calculation of local similarities between matches using a Two-Stream Architecture. In contrast to CSR-Net, CSR-Net++ shifts from using the PointNet architecture to estimate global transformation models to employing it for computing global similarities between matches. Furthermore, CSR-Net++ incorporates raw image information and combines it with spatial information of matches to jointly represent the local similarity of matches. 



**Major Concerns:**

1. For the $k \times D$ tensor in Figure 2, CSR-Net performs Max Pooling operation along the dimension of $k$ to ensure permutation invariance of STR. However, CSR-Net++ conducts segmented dot product and linear projection along the dimension of $D$. What operation in CSR-Net++ ensures permutation invariance of STR, and why does this operation guarantee permutation invariance? This needs to be emphasized in the paper.
2. Where are the experimental data for datasets SUIR and MTI located? What is the relationship between the datasets RS-satellite and RS-UAV introduced in Section 4.4 and the datasets mentioned in Section 4.2? Which datasets do the images in Figures 4 and 6 come from, respectively? How did the authors obtain the Ground Truth for the OxBs dataset? Is it possible to provide the relevant files? It seems that the MTI dataset cannot be obtained. Can the authors provide relevant links or acquisition methods?
3. In Section 4.5 Image Registration, the paper should clarify which methods are used to compute the transformation models TPS and the homography matrix. Different computation methods might lead to different experimental results. Additionally, it seems that Figure 6 only displays the image registration results using the homography matrix as the transformation model.
4. The paper should discuss the effects of the hyperparameters Patch-size, $C$, and $D$ on the algorithm's performance, concerning Figure 2.
5. The paper should provide an analysis of the shortcomings of the proposed method and future directions for improvement at the conclusion.
6. The experimental data on the datasetes cannot be referred to as a contribution of the method. It is recommended to rephrase the language in the fifth paragraph of the Introduction.



**Minor Concerns:**

1. Variables should be adequately explained when they first appear. For example, $n$ in Equation 5 and $C$ and $D$ in Equation 6.

2. The algorithmic details depicted in Figure 1 are not clear enough, especially in the first row of Figure 1 (see below). The selected part of the blue box is easy to mislead the reader, thus making the reader think that the dimensions of the tensors in the model cannot be aligned. It is suggested to revise the figure based on the flowchart of the PointNet Segmentation Network or annotate the necessary tensors and their dimensions on Figure 1. The two red box selected areas and the relationship between them in the following figure lack necessary explanation, and it is suggested to explain them in combination with Equation 4.

   ![](CSR-Net++：重新思考用于特征匹配的上下文结构表示学习/审稿1.jpg)

3. The PointNet Encoder and CNN Encoder in Figure 1 lack necessary parameter explanations. The Rotation Invariant Layer lacks specific operational details.

4. In Equation 6, $\mathcal{P}_i^i$ contains two instances of the variable $i$. The meanings of these two $i$ seem to be different, suggesting a modification of the variable name here. It is recommended to clarify the relationship between $\mathcal{P}_i$ and $\mathcal{P}_i^i$ in the paper.

5. It is suggested to explain in the paper the relationship between the Spatial STR in Figure 2 and the $\mathcal{R}_i$, $\mathcal{R}_{ij}$ mentioned in the text.

6. The expression for $\mathcal{L}_{local}$ in Equation 7 should be provided.



**Summary Of The Review:**

Overall, the method proposed in this paper has a good idea. However, the description of the method in the paper is not clear enough, and further organization of the language is needed.
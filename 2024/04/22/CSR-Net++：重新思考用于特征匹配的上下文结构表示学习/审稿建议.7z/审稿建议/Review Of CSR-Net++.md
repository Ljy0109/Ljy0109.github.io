# **Review Of CSR-Net++**



**Summary Of The Paper:**

This paper builds upon CSR-Net and proposes an enhanced method, CSR-Net++, for the task of mismatch removal. Given a set of putative matches, the global similarity between matches is computed using the PointNet architecture, followed by the calculation of local similarities between matches using a Two-Stream Architecture. In contrast to CSR-Net, CSR-Net++ shifts from using the PointNet architecture to estimate global transformation models to employing it for computing global similarities between matches. Furthermore, CSR-Net++ incorporates raw image information and combines it with spatial information of matches to jointly represent the local similarity of matches. 



**Major Concerns:**

1. For the $k \times D$ tensor in Figure 2, CSR-Net performs Max Pooling operation along the dimension of $k$ to ensure permutation invariance of STR. However, CSR-Net++ conducts segmented dot product and linear projection along the dimension of $D$. What operation in CSR-Net++ ensures permutation invariance of STR, and why does this operation guarantee permutation invariance? This needs to be emphasized in the paper.
2. How did the authors obtain the Ground Truth for the OxBs dataset? Is it possible to provide the relevant files? It seems that the MTI dataset cannot be obtained. Can the authors provide relevant links or acquisition methods?
3. In Section 4.5 Image Registration, the paper should clarify which methods are used to compute the transformation models TPS and the homography matrix. Different computation methods might lead to different experimental results. Additionally, it seems that Figure 6 only displays the image registration results using the homography matrix as the transformation model.
4. The paper should discuss the effects of the hyperparameters Patch-size, $C$, and $D$ on the algorithm's performance, concerning Figure 2.
5. The paper should provide an analysis of the shortcomings of the proposed method and future directions for improvement at the conclusion.
6. The experimental data on the datasetes cannot be referred to as a contribution of the method. It is recommended to rephrase the language in the fifth paragraph of the Introduction.



**Minor Concerns:**

1. Variables should be adequately explained when they first appear. For example, $n$ in Equation 5 and $C$ and $D$ in Equation 6.

2. The algorithmic details depicted in Figure 1 are not clear enough, especially in the first row of Figure 1 (see below). The selected part of the blue box is easy to mislead the reader, thus making the reader think that the dimensions of the tensors in the model cannot be aligned. It is suggested to revise the figure based on the flowchart of the PointNet Segmentation Network or annotate the necessary tensors and their dimensions on Figure 1. The two red box selected areas and the relationship between them in the following figure lack necessary explanation, and it is suggested to explain them in combination with Equation 4.

   ![](E:\Code\blog\source\_posts\CSR-Net++：重新思考用于特征匹配的上下文结构表示学习\审稿1.jpg)

3. The PointNet Encoder and CNN Encoder in Figure 1 lack necessary parameter explanations. The Rotation Invariant Layer lacks specific operational details.

4. In Equation 6, $\mathcal{P}_i^i$ contains two instances of the variable $i$. The meanings of these two $i$ seem to be different, suggesting a modification of the variable name here. It is recommended to clarify the relationship between $\mathcal{P}_i$ and $\mathcal{P}_i^i$ in the paper.

5. It is suggested to explain in the paper the relationship between the Spatial STR in Figure 2 and the $\mathcal{R}_i$, $\mathcal{R}_{ij}$ mentioned in the text.

6. The expression for $\mathcal{L}_{local}$ in Equation 7 should be provided.



**Summary Of The Review:**

Overall, the method proposed in this paper has a good idea. However, the description of the method in the paper is not clear enough, and further organization of the language is needed.







Summary of the paper:

This paper builds upon CSR-Net and proposes an enhanced method, CSR-Net++, for the task of mismatch removal. Given a set of putative matches, the global similarity between matches is computed using the PointNet architecture, followed by the calculation of local similarities between matches using a Two-Stream architecture. Compared with CSR-Net, CSR-Net++ uses PointNet architecture to calculate the global similarity between matches instead of estimating the global transformation model, and it modifies the distance measure function in CSR-Net based on the global similarity. Furthermore, CSR-Net++ incorporates raw image information and combines it with spatial information of matches to jointly represent the local similarity of matches. 


Major concerns:

1. For the k×D tensor in Figure 2, CSR-Net performs Max Pooling operation along the dimension of k to ensure permutation invariance of STR. However, CSR-Net++ conducts segmented dot product and linear projection along the dimension of D. What operation in CSR-Net++ ensures permutation invariance of STR, and why does this operation guarantee permutation invariance? This needs to be emphasized in the paper.

2. Where are the experimental data for datasets SUIR and MTI located? What is the relationship between the datasets RS-satellite and RS-UAV introduced in Section 4.4 and the datasets mentioned in Section 4.2? Which datasets do the images in Figures 4 and 6 come from, respectively? How did the authors obtain the Ground Truth for the OxBs dataset? Is it possible to provide the relevant files? It seems that the MTI dataset cannot be obtained. Can the authors provide relevant links or acquisition methods?

3. In Section 4.5 Image Registration, the paper should clarify which method is used to compute the transformation models TPS and the homography matrix. Different computation methods might lead to different experimental results. Additionally, it seems that Figure 6 only displays the image registration results using the homography matrix as the transformation model.

4. The paper should discuss the effects of the hyperparameters Patch-size, C, and D on the algorithm's performance, concerning Figure 2.

5. The paper should provide an analysis of the shortcomings of the proposed method and future directions for improvement at the conclusion.

6. The experimental data on the datasets cannot be referred to as a contribution of the method. It is suggested to rephrase the language in the fifth paragraph of the Introduction.


Minor concerns:

1. Variables should be adequately explained when they first appear. For example, n in Equation 5 and C and D in Equation 6.

2. The algorithmic details depicted in Figure 1 are not clear enough, especially in the first row of Figure 1. It is suggested to revise the figure based on the flowchart of the PointNet Segmentation Network or annotate the necessary tensors and their dimensions on Figure 1. The PointNet Encoder and CNN Encoder in Figure 1 lack necessary parameter explanations. The Rotation Invariant Layer lacks specific operational details.

3. In Equation 6, P<sup>i</sup><sub>i</sub> contains two instances of the variable i. The meanings of these two i seem to be different, suggesting a modification of the variable name here. It is suggested to clarify the relationship between P<sub>i</sub> and P<sup>i</sup><sub>i</sub> in the paper.

4. It is suggested to explain in the paper the relationship between the Spatial STR in Figure 2 and the R<sub>i</sub>, R<sub>ij</sub> mentioned in Section 3.3.

5. The expression for L<sub>local</sub> in Equation 7 should be provided.


Summary of the review: 

Overall, the method proposed in this paper has a good idea. However, the description of the method in the paper is not clear enough, and further organization of the language is needed.